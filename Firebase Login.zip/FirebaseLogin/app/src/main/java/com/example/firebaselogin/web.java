package com.example.firebaselogin;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class web extends AppCompatActivity {
    WebView webView;



    private Button stopButton;
    public ProgressBar progressBar;
    ImageView imageMenu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        webView = findViewById(R.id.webwiew);



        stopButton = findViewById(R.id.stopButton);
        Button readButton = findViewById(R.id.readButton);





        progressBar=findViewById(R.id.progressbar);




        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(MainActivity.message);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.addJavascriptInterface(new MyJavaScriptInterface(), "HTMLOUT");


        //offline 4 line
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webSettings.setAllowFileAccess(true);
        webSettings.setDomStorageEnabled(true);


        readButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                webView.evaluateJavascript(
                        "javascript:(function() { " +
                                "var textContent = document.getSelection().toString();" +
                                "if (textContent.trim() !== '') {" +
                                "   HTMLOUT.processHTML(textContent);" +
                                "}" +
                                "})()",
                        null);


            }

        });


        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextToSpeechManager.getInstance().stop();
            }
        });



        webView.setWebViewClient(new WebViewClient(){

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.INVISIBLE);
                setTitle("Loading......");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                //setTitle(view.getTitle());
            }
        });


    }



    private class MyJavaScriptInterface {
        @SuppressLint("JavascriptInterface")
        @JavascriptInterface
        public void processHTML(String html) {
            if (html != null && !html.trim().isEmpty()) {
                //speak the copied text

                TextToSpeechManager.getInstance().speak(web.this, html);
            } else {
                Toast.makeText(web.this, "No text selected", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        //release TextToSpeech instance
        TextToSpeechManager.getInstance().release();
    }




    private class MywebClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }



    @Override
    public void onBackPressed() {
        if(webView.isFocused() && webView.canGoBack())
        {
            webView.goBack();
        }else{
            //(back button a click korle kaj hobena)  super.onBackPressed();

            Intent intent = new Intent(web.this,MainActivity.class);
            startActivity(intent);
            finish();
        }

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}
