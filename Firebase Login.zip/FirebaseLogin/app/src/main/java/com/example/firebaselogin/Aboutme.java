package com.example.firebaselogin;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Aboutme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutme);
    }

    @Override
    public void onBackPressed() {

            Intent intent = new Intent(Aboutme.this,MainActivity.class);
            startActivity(intent);
            finish();
        }

    }
