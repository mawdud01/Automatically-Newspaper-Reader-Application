package com.example.firebaselogin;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

public class TextToSpeechManager {

    private TextToSpeech tts;

    private static volatile TextToSpeechManager instance;

    public static TextToSpeechManager getInstance() {
        if (instance == null) {
            synchronized (TextToSpeechManager.class) {
                if (instance == null) {
                    instance = new TextToSpeechManager();
                }
            }
        }
        return instance;
    }

    public void speak(final Context context, final String text) {
        release(); // release any previous instances of TextToSpeech

        tts = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {

                    // tts.setLanguage(Locale.US);
                    tts.setLanguage(new Locale("bn_BD"));
                    if (text != null && !text.isEmpty()) {
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                    }
                }
            }
        });
    }

    public void release() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
    }





    public void stop() {
        if (tts != null && tts.isSpeaking()) {
            tts.stop();
        }
    }



}
