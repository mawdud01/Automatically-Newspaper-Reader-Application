package com.example.firebaselogin;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle toggle;

    ImageView imageMenu;

    TextView subheader;
    private ListView listView;
    private SearchView searchView;
    private Customadapter adapter;
    public static String message =null;

    public ProgressBar progressBar;
    private List<Item> itemList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview);
        searchView = findViewById(R.id.search_bar1);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_View);
        imageMenu = findViewById(R.id.imageMenu);


        itemList.add(new Item(R.drawable.prothomalo, "prothomalo"));
        itemList.add(new Item(R.drawable.bangladesh_protidin, "bangladesh_protidin"));
        itemList.add(new Item(R.drawable.ittefaq, "ittefaq"));
        itemList.add(new Item(R.drawable.kalerkontho, "kalerkontho"));
        itemList.add(new Item(R.drawable.amader_somoy, "amader_somoy"));
        itemList.add(new Item(R.drawable.jugantor, "jugantor"));
        itemList.add(new Item(R.drawable.dailystar, "dailystar"));
        itemList.add(new Item(R.drawable.manobjomin, "manobjomin"));
        itemList.add(new Item(R.drawable.boinikbarta, "boinikbarta"));
        itemList.add(new Item(R.drawable.jonokhonto, "jonokhonto"));
        itemList.add(new Item(R.drawable.jagonews, "jagonews"));
        itemList.add(new Item(R.drawable.bhorer_kagoj, "bhorer_kagoj"));
        itemList.add(new Item(R.drawable.inqilab, "inqilab"));
        itemList.add(new Item(R.drawable.manobkontho, "manobkontho"));
        itemList.add(new Item(R.drawable.alokitobangladesh, "alokitobangladesh"));
        itemList.add(new Item(R.drawable.ajker_potrika, "ajker_potrika"));
        itemList.add(new Item(R.drawable.somoyer_konthosor, "somoyer_konthosor"));
        itemList.add(new Item(R.drawable.somoy_news, "somoy_news"));
        itemList.add(new Item(R.drawable.sbnation, "sbnation"));
        itemList.add(new Item(R.drawable.aljajira, "aljajira"));
        itemList.add(new Item(R.drawable.bangla_news_24, "bangla_news_24"));
        itemList.add(new Item(R.drawable.bss_news, "bss_news"));
        itemList.add(new Item(R.drawable.bolanews24, "bolanews24"));
        itemList.add(new Item(R.drawable.comulla_kagoj, "comulla_kagoj"));
        itemList.add(new Item(R.drawable.cakrirkhobor, "cakrirkhobor"));
        itemList.add(new Item(R.drawable.chandpur_news, "chandpur_news"));
        itemList.add(new Item(R.drawable.chandpur_times, "chandpur_times"));
        itemList.add(new Item(R.drawable.bangla_tribune, "bangla_tribune"));
        itemList.add(new Item(R.drawable.brahmanbariatime_, "brahmanbariatime_"));
        itemList.add(new Item(R.drawable.borishal, "borishal"));
        itemList.add(new Item(R.drawable.daily_sun, "daily_sun"));
        itemList.add(new Item(R.drawable.dailycampus, "dailycampus"));
        itemList.add(new Item(R.drawable.dailymirror, "dailymirror"));
        itemList.add(new Item(R.drawable.ctg, "ctg"));
        itemList.add(new Item(R.drawable.cnbc_busniss, "cnbc_busniss"));
        itemList.add(new Item(R.drawable.dhakajpsot, "dhakajpsot"));
        itemList.add(new Item(R.drawable.dhaka, "dhaka"));
        itemList.add(new Item(R.drawable.dhaka_times, "dhaka_times"));
        itemList.add(new Item(R.drawable.dwbd, "dwbd"));
        itemList.add(new Item(R.drawable.espn, "espn"));
        itemList.add(new Item(R.drawable.dk_bangla, "dk_bangla"));
        itemList.add(new Item(R.drawable.euro_sports, "euro_sports"));
        itemList.add(new Item(R.drawable.financetime, "financetime"));
        itemList.add(new Item(R.drawable.financial_express_bd, "financial_express_bd"));
        itemList.add(new Item(R.drawable.foridpur_dristic, "foridpur_dristic"));
        itemList.add(new Item(R.drawable.foxnews, "foxnews"));
        itemList.add(new Item(R.drawable.gazipurnews, "gazipurnews"));
        itemList.add(new Item(R.drawable.gramernews_joshor, "gramernews_joshor"));
        itemList.add(new Item(R.drawable.independent, "independent"));
        itemList.add(new Item(R.drawable.jamalpur_ajkernews, "jamalpur_ajkernews"));
        itemList.add(new Item(R.drawable.jalokati_alorpotidin, "jalokati_alorpotidin"));
        itemList.add(new Item(R.drawable.jayjaydin, "jayjaydin"));
        itemList.add(new Item(R.drawable.jomunanews, "jomunanews"));
        itemList.add(new Item(R.drawable.purbancol_khulna, "purbancol_khulna"));
        itemList.add(new Item(R.drawable.khulna, "khulna"));
        itemList.add(new Item(R.drawable.kurigram_live, "kurigram_live"));
        itemList.add(new Item(R.drawable.lokhipur_news24, "lokhipur_news24"));
        itemList.add(new Item(R.drawable.losangelstime, "losangelstime"));
        itemList.add(new Item(R.drawable.magura_news, "magura_news"));
        itemList.add(new Item(R.drawable.maymansing, "maymansing"));
        itemList.add(new Item(R.drawable.maraca, "maraca"));
        itemList.add(new Item(R.drawable.mathabanga_cuadanga, "mathabanga_cuadanga"));
        itemList.add(new Item(R.drawable.narayngonjlive, "narayngonjlive"));
        itemList.add(new Item(R.drawable.netrokona_daily, "netrokona_daily"));
        itemList.add(new Item(R.drawable.noakhli, "noakhli"));
        itemList.add(new Item(R.drawable.norshindi_times, "norshindi_times"));
        itemList.add(new Item(R.drawable.noyadigonto, "noyadigonto"));
        itemList.add(new Item(R.drawable.ntvnewsbd, "ntvnewsbd"));
        itemList.add(new Item(R.drawable.pabna_news, "pabna_news"));
        itemList.add(new Item(R.drawable.phonearena, "phonearena"));
        itemList.add(new Item(R.drawable.pirojpur_khonto, "pirojpur_khonto"));
        itemList.add(new Item(R.drawable.poriborton, "poriborton"));
        itemList.add(new Item(R.drawable.priyo_logo, "priyo_logo"));
        itemList.add(new Item(R.drawable.probashdigontoo, "probashdigontoo"));
        itemList.add(new Item(R.drawable.purbokon, "purbokon"));
        itemList.add(new Item(R.drawable.rajbari_news, "rajbari_news"));
        itemList.add(new Item(R.drawable.rajsahi, "rajsahi"));
        itemList.add(new Item(R.drawable.rajsahi_sonalisongbad, "rajsahi_sonalisongbad"));
        itemList.add(new Item(R.drawable.bagerhat, "bagerhat"));
        itemList.add(new Item(R.drawable.risingbd, "risingbd"));
        itemList.add(new Item(R.drawable.rongpur, "rongpur"));
        itemList.add(new Item(R.drawable.rongpur_news, "rongpur_news"));
        itemList.add(new Item(R.drawable.rtv_online, "rtv_online"));
        itemList.add(new Item(R.drawable.sarabangla, "sarabangla"));
        itemList.add(new Item(R.drawable.satkhira_logo, "satkhira_logo"));
        itemList.add(new Item(R.drawable.sharenews, "sharenews"));
        itemList.add(new Item(R.drawable.sherpur_times, "sherpur_times"));
        itemList.add(new Item(R.drawable.sikha, "sikha"));
        itemList.add(new Item(R.drawable.sirajgonj_news, "sirajgonj_news"));
        itemList.add(new Item(R.drawable.skynews, "skynews"));
        itemList.add(new Item(R.drawable.splash_bdnew, "splash_bdnew"));
        itemList.add(new Item(R.drawable.sylhet_daily, "sylhet_daily"));
        itemList.add(new Item(R.drawable.sylhet, "sylhet"));
        itemList.add(new Item(R.drawable.timesindia, "timesindia"));
        itemList.add(new Item(R.drawable.thegurdian, "thegurdian"));
        itemList.add(new Item(R.drawable.techcurner, "techcurner"));
        itemList.add(new Item(R.drawable.observer_eng, "observer_eng"));
        itemList.add(new Item(R.drawable.narail, "narail"));
        itemList.add(new Item(R.drawable.techsohor, "techsohor"));
        itemList.add(new Item(R.drawable.azadi, "azadi"));
        itemList.add(new Item(R.drawable.naogaon, "naogaon"));





        adapter = new Customadapter(this, itemList);
        listView.setAdapter(adapter);



       // Customadapter adapter=new Customadapter(MainActivity.this,countryNames,newspaperimage);
       // listView.setAdapter(adapter);





        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                switch (item.getItemId()) {
                    case R.id.mHome:

                        Toast.makeText(MainActivity.this, "No Backed Work in Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;

                    case R.id.mShare:
                        Toast.makeText(MainActivity.this, "No Backed Work in Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.about:
                        Toast.makeText(MainActivity.this, "About Developer", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(MainActivity.this,Aboutme.class);
                        startActivity(intent);
                        finish();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.policy:

                        Intent intent2 = new Intent(MainActivity.this,Policy.class);
                        startActivity(intent2);
                        finish();
                        drawerLayout.closeDrawers();
                        break;

                    case R.id.mRate:
                        showRatingDialog();
                        drawerLayout.closeDrawers();
                        break;
                }

                return false;
            }
        });







        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Item item = (Item) parent.getItemAtPosition(position);
                Toast.makeText(MainActivity.this, item.getName() + " is opening... ", Toast.LENGTH_SHORT).show();


                if (item.getName().equals("prothomalo")) {
                    message = "https://www.prothomalo.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bangladesh_protidin")) {

                    message = "https://www.bd-pratidin.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("ittefaq")) {

                    message = "https://www.ittefaq.com.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("kalerkontho")) {

                    message = "https://www.kalerkantho.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("amader_somoy")) {

                    message = "https://www.dainikamadershomoy.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jugantor")) {

                    message = "https://www.jugantor.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dailystar")) {

                    message = "https://www.thedailystar.net/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("manobjomin")) {

                    message = "https://mzamin.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("boinikbarta")) {

                    message = "https://bonikbarta.net/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jonokhonto")) {

                    message = "https://www.dailyjanakantha.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jagonews")) {

                    message = "https://www.jagonews24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bhorer_kagoj")) {

                    message = "https://www.bhorerkagoj.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("inqilab")) {

                    message = "https://www.dailyinqilab.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("manobkontho")) {

                    message = "https://www.manobkantha.com.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("alokitobangladesh")) {

                    message = "https://www.alokitobangladesh.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("ajker_potrika")) {

                    message = "https://www.ajkerpatrika.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("somoyer_konthosor")) {

                    message = "https://www.somoyerkonthosor.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("somoy_news")) {

                    message = "https://www.somoynews.tv/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sbnation")) {

                    message = "https://www.sbnation.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("aljajira")) {

                    message = "hthttps://www.aljazeera.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bangla_news_24")) {

                    message = "https://www.banglanews24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bss_news")) {

                    message = "https://www.bssnews.net/bangla/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bolanews24")) {

                    message = "https://www.bholanews.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("comulla_kagoj")) {

                    message = "https://www.comillarkagoj.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("cakrirkhobor")) {

                    message = "https://chakrirkhobor.com.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("chandpur_news")) {

                    message = "https://chandpurnews.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("chandpur_times")) {

                    message = "https://chandpurtimes.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bangla_tribune")) {

                    message = "https://www.banglatribune.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("brahmanbariatime_")) {

                    message = "https://brahmanbariatimes.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("borishal")) {

                    message = "https://barishalnews.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("daily_sun")) {

                    message = "https://www.daily-sun.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dailycampus")) {

                    message = "https://thedailycampus.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dailymirror")) {

                    message = "https://www.mirror.co.uk/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("ctg")) {

                    message = "http://www.chittagongdiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("cnbc_busniss")) {

                    message = "https://www.cnbc.com/world/?region=world";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dhakajpsot")) {

                    message = "https://www.dhakapost.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dhaka")) {

                    message = "http://www.dhakadiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dhaka_times")) {

                    message = "https://www.dhakatimes24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dwbd")) {

                    message = "https://www.dw.com/bn/%E0%A6%AC%E0%A6%BF%E0%A6%B7%E0%A7%9F/s-11929";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("espn")) {

                    message = "https://www.espn.in/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("dk_bangla")) {

                    message = "https://bangla.dhakatribune.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("euro_sports")) {

                    message = "https://www.eurosport.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("financetime")) {

                    message = "https://www.ft.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("financial_express_bd")) {

                    message = "https://thefinancialexpress.com.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("foridpur_dristic")) {

                    message = "https://dailyfaridpurkantho.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("foxnews")) {

                    message = "https://www.fox-nox.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("gazipurnews")) {

                    message = "https://www.dailygazipuronline.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("gramernews_joshor")) {

                    message = "https://www.gramerkagoj.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("independent")) {

                    message = "https://www.independent24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jamalpur_ajkernews")) {

                    message = "https://ajkerjamalpur.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jalokati_alorpotidin")) {

                    message = "https://dainikalorprotidin.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jayjaydin")) {

                    message = "https://www.jaijaidinbd.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("jomunanews")) {

                    message = "https://www.jamuna.tv/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("purbancol_khulna")) {

                    message = "https://epaper.purbanchal.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("khulna")) {

                    message = "http://www.khulnadiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("kurigram_live")) {

                    message = "http://www.kurigram.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("lokhipur_news24")) {

                    message = "https://lakshmipur24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("losangelstime")) {

                    message = "https://www.latimes.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("magura_news")) {

                    message = "https://www.maguranews.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("maymansing")) {

                    message = "http://www.mymensinghdiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("maraca")) {

                    message = "https://www.marca.com/en/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("mathabanga_cuadanga")) {

                    message = "https://www.mathabhanga.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("narayngonjlive")) {

                    message = "https://www.livenarayanganj.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("netrokona_daily")) {

                    message = "https://www.dailynetrokona.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("noakhli")) {

                    message = "https://www.noakhalisomachar.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("norshindi_times")) {

                    message = "https://narsingditimes.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("noyadigonto")) {

                    message = "https://www.dailynayadiganta.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("ntvnewsbd")) {

                    message = "https://www.ntvbd.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("pabna_news")) {

                    message = "https://pabnabarta24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("phonearena")) {

                    message = "https://www.phonearena.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("pirojpur_khonto")) {

                    message = "https://pirojpurkantho.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("poriborton")) {

                    message = "";
                    Toast.makeText(MainActivity.this, "Sorry this page is not found..", Toast.LENGTH_SHORT).show();
                } else if (item.getName().equals("priyo_logo")) {

                    message = "https://m.priyo.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("probashdigontoo")) {

                    message = "https://www.probashirdiganta.com/en";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("purbokon")) {

                    message = "https://www.edainikpurbokone.net/index.php?page=1&date=2023-03-03";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("rajbari_news")) {

                    message = "https://dailyrajbarikantha.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("rajsahi")) {

                    message = "http://www.rajshahidiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("rajsahi_sonalisongbad")) {

                    message = "https://sonalisangbad.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("bagerhat")) {


                    message = "https://bagerhat24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("risingbd")) {

                    message = "https://www.risingbd.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("rongpur")) {

                    message = "http://www.rangpurdiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("rongpur_news")) {

                    message = "https://www.uttorbangla.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("rtv_online")) {

                    message = "https://www.rtvonline.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sarabangla")) {

                    message = "https://sarabangla.net/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("satkhira_logo")) {

                    message = "https://dailysatkhira.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sharenews")) {

                    message = "https://www.sharenews24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sherpur_times")) {

                    message = "https://sherpurtimes.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sikha")) {

                    message = "https://www.dainikshiksha.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sirajgonj_news")) {

                    message = "https://sirajganjkantho.news/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("skynews")) {

                    message = "https://news.sky.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("splash_bdnew")) {

                    message = "https://allonlinebanglanewspapers.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sylhet_daily")) {

                    message = "https://dailysylhet.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("sylhet")) {

                    message = "http://www.sylhetdiv.gov.bd/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("timesindia")) {

                    message = "https://timesofindia.indiatimes.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("thegurdian")) {

                    message = "https://www.theguardian.com/international";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("techcurner")) {

                    message = "https://techcrunch.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("observer_eng")) {

                    message = "https://www.observerbd.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("narail")) {

                    message = "https://narailnews24.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("techsohor")) {

                    message = "https://techshohor.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("azadi")) {

                    message = "https://dainikazadi.net/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();
                } else if (item.getName().equals("naogaon")) {

                    message = "https://www.naogaondorpon.com/";
                    Intent intent = new Intent(MainActivity.this, web.class);
                    startActivity(intent);
                    finish();


                }
            }
        });



        imageMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });




        // Set up the search view
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });


    }






    @Override
    public void onBackPressed() {
        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        alert.setTitle("Exit App");
        alert.setMessage("Do You Want to Exit ");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                finishAffinity();
            }
        });

        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                Intent intent=new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
                dialogInterface.dismiss();

            }
        });

        alert.show();
        //super.onBackPressed();
    }












    private void showRatingDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Rate My App");
        builder.setMessage("Please rate my app");
        builder.setPositiveButton("Rate now", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // take the user to the app store for rating
            }
        });
        builder.setNegativeButton("Not now", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }


}
