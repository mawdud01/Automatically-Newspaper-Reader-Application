package com.example.onlinenewspaper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class Policy extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy);




    }

    @Override
    public void onBackPressed() {
            //(back button a click korle kaj hobena)  super.onBackPressed();

            Intent intent = new Intent(Policy.this,MainActivity.class);
            startActivity(intent);
            finish();
        }

    }
