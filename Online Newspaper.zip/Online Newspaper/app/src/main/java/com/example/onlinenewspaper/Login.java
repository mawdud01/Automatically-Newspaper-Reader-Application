package com.example.onlinenewspaper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;

public class Login extends AppCompatActivity {

    EditText username,show;

    Button login,skip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username=findViewById(R.id.username);
        login=findViewById(R.id.login);
        skip=findViewById(R.id.skip);





        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(Login.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });















        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(username.getText().toString().equals(""))
                {
                    Toast.makeText(Login.this, "Please write Your Name", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent intent=new Intent(Login.this,MainActivity.class);
                    startActivity(intent);
                    finish();



                }













            }
        });

    }





    @Override
    public void onBackPressed() {
        AlertDialog.Builder alert = new AlertDialog.Builder(Login.this);
        alert.setTitle("Exit App");
        alert.setMessage("Do You Want to Exit ");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                finishAffinity();
            }
        });

        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

            }
        });

        alert.show();
        //super.onBackPressed();










    }



}